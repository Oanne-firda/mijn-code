import random
import string

# Oanne Posthumus

# DATA
locaties = ["het Donkere Bos", "de Verlaten Ruïne", "de Ondergrondse Grot", "het Mistige Moeras"]
monsters = ["een troll", "een draak", "een skelettenridder", "een schaduwbeest"]
schatten = ["een gouden amulet", "een magisch zwaard", "een zak edelstenen", "een mysterieuze sleutel"]
goede_eindes = ["Je keert als held terug naar huis!", "Je vindt een verborgen schatkamer en leeft rijk verder."]
slechte_eindes = ["Je wordt verslagen en niemand hoort ooit nog van je...", "Je verdwaalt voor altijd in het duister."]
neutrale_eindes = ["Je ontsnapt ternauwernood, maar zonder buit.", "Je avontuur eindigt rustig, maar zonder glorie."]

# START
print("Welkom bij het Avonturenspel!")
naam = input("Wat is jouw naam, avonturier? ")

print(f"\nMooi zo, {naam}. Jouw avontuur begint nu...\n")

# LOCATIE
locatie = random.choice(locaties)
print(f"Je arriveert bij {locatie}. De lucht voelt zwaar en iets lijkt je te observeren.")

# KEUZE 1
print("\nWat doe je?")
print("1) Je gaat naar binnen / verder verkennen")
print("2) Je draait om en zoekt een andere route")

keuze1 = input("> ")

if keuze1 == "1":
    print(f"\nDapper, {naam}! Je stapt dieper {locatie} in.")
else:
    print(f"\nVoorzichtig, {naam}. Je kiest een veiligere route...")
    locatie = random.choice(locaties)
    print(f"Maar helaas: je komt alsnog uit bij {locatie}!")

# MONSTER
monster = random.choice(monsters)
print(f"\nPlots verschijnt {monster}! Het gromt en blokkeert je pad.")

# KEUZE 2
print("\nWat doe je?")
print("1) Je valt aan")
print("2) Je probeert te vluchten")

keuze2 = input("> ")

# UITKOMST
geluk = random.random()

if keuze2 == "1":
    if geluk > 0.7:
        schat = random.choice(schatten)
        print(f"\nJe verslaat {monster}! Tussen de resten vind je {schat}.")
        einde = random.choice(goede_eindes)
    else:
        print(f"\n{monster} is te sterk. Je wordt verslagen...")
        einde = random.choice(slechte_eindes)
else:
    if geluk > 0.7:
        print(f"\nJe rent zo hard als je kunt en weet te ontsnappen!")
        einde = random.choice(neutrale_eindes)
    else:
        print(f"\nJe struikelt! {monster} haalt je in...")
        einde = random.choice(slechte_eindes)

#  EINDE 
print("\nEINDE VAN HET AVONTUUR")
print(einde)